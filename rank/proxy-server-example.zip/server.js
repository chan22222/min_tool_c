const express = require('express');
const cors = require('cors');
const axios = require('axios');
const NodeCache = require('node-cache');

const app = express();
const PORT = 3001;

// 5분 캐시
const cache = new NodeCache({ stdTTL: 300 });

// CORS 설정
app.use(cors({
  origin: '*', // 실제 운영시에는 특정 도메인으로 제한
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type']
}));

app.use(express.json());

// Keep-Alive 설정으로 연결 재사용
const http = require('http');
const https = require('https');

const httpAgent = new http.Agent({ 
  keepAlive: true, 
  maxSockets: 50,
  timeout: 10000
});

const httpsAgent = new https.Agent({ 
  keepAlive: true, 
  maxSockets: 50,
  timeout: 10000
});

// 네이버 검색에 최적화된 헤더
const getOptimizedHeaders = () => ({
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
  'Accept-Language': 'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7',
  'Accept-Encoding': 'gzip, deflate, br',
  'Referer': 'https://search.naver.com/',
  'Connection': 'keep-alive',
  'Upgrade-Insecure-Requests': '1',
  'Sec-Fetch-Dest': 'document',
  'Sec-Fetch-Mode': 'navigate',
  'Sec-Fetch-Site': 'same-origin',
  'Cache-Control': 'max-age=0'
});

// 기본 프록시 엔드포인트
app.get('/proxy', async (req, res) => {
  try {
    const targetUrl = req.query.url;
    
    if (!targetUrl) {
      return res.status(400).json({ error: 'URL parameter is required' });
    }

    // 캐시 키 생성
    const cacheKey = Buffer.from(targetUrl).toString('base64');
    
    // 캐시 확인
    const cached = cache.get(cacheKey);
    if (cached) {
      console.log(`💾 캐시에서 반환: ${targetUrl.substring(0, 50)}...`);
      res.set('X-Cache', 'HIT');
      return res.send(cached);
    }

    console.log(`🔍 새로운 요청: ${targetUrl.substring(0, 50)}...`);

    const response = await axios.get(targetUrl, {
      headers: getOptimizedHeaders(),
      timeout: 15000,
      httpAgent,
      httpsAgent,
      maxRedirects: 5,
      validateStatus: status => status < 500 // 4xx 에러도 처리
    });

    // 캐시에 저장
    cache.set(cacheKey, response.data);
    
    res.set({
      'X-Cache': 'MISS',
      'X-Response-Time': response.headers['response-time'] || 'N/A'
    });
    
    res.send(response.data);
    
  } catch (error) {
    console.error('❌ 프록시 에러:', error.message);
    
    // 더 자세한 에러 정보 제공
    const errorResponse = {
      error: 'Proxy request failed',
      details: error.message,
      code: error.code,
      status: error.response?.status,
      url: req.query.url?.substring(0, 100)
    };
    
    res.status(error.response?.status || 500).json(errorResponse);
  }
});

// 배치 처리 엔드포인트 (여러 URL 동시 처리)
app.post('/proxy/batch', async (req, res) => {
  try {
    const { urls } = req.body;
    
    if (!Array.isArray(urls) || urls.length === 0) {
      return res.status(400).json({ error: 'URLs array is required' });
    }

    if (urls.length > 10) {
      return res.status(400).json({ error: 'Too many URLs. Maximum 10 allowed.' });
    }

    console.log(`🔄 배치 처리: ${urls.length}개 URL`);

    const promises = urls.map(async (url, index) => {
      try {
        const cacheKey = Buffer.from(url).toString('base64');
        const cached = cache.get(cacheKey);
        
        if (cached) {
          return { index, success: true, data: cached, cached: true };
        }

        const response = await axios.get(url, {
          headers: getOptimizedHeaders(),
          timeout: 15000,
          httpAgent,
          httpsAgent
        });

        cache.set(cacheKey, response.data);
        return { index, success: true, data: response.data, cached: false };
        
      } catch (error) {
        return { 
          index, 
          success: false, 
          error: error.message,
          status: error.response?.status 
        };
      }
    });

    const results = await Promise.all(promises);
    
    const successCount = results.filter(r => r.success).length;
    console.log(`✅ 배치 완료: ${successCount}/${urls.length} 성공`);
    
    res.json({ 
      results, 
      summary: { 
        total: urls.length, 
        success: successCount, 
        failed: urls.length - successCount 
      }
    });
    
  } catch (error) {
    console.error('❌ 배치 처리 에러:', error.message);
    res.status(500).json({ error: 'Batch processing failed', details: error.message });
  }
});

// 캐시 상태 확인
app.get('/cache/stats', (req, res) => {
  const stats = cache.getStats();
  res.json({
    ...stats,
    cacheSize: cache.keys().length,
    memoryUsage: process.memoryUsage()
  });
});

// 캐시 초기화
app.delete('/cache', (req, res) => {
  cache.flushAll();
  res.json({ message: 'Cache cleared successfully' });
});

// 서버 상태 확인
app.get('/health', (req, res) => {
  res.json({ 
    status: 'healthy', 
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
    version: '1.0.0'
  });
});

app.listen(PORT, () => {
  console.log(`🚀 네이버 블로그 프록시 서버가 http://localhost:${PORT} 에서 실행 중입니다`);
  console.log(`📊 상태 확인: http://localhost:${PORT}/health`);
  console.log(`💾 캐시 상태: http://localhost:${PORT}/cache/stats`);
});

// 우아한 종료
process.on('SIGTERM', () => {
  console.log('🔄 서버를 우아하게 종료 중...');
  cache.close();
  process.exit(0);
});