// PKG를 사용해 EXE 파일 생성하는 스크립트
const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');

console.log('🔨 EXE 파일 빌드 시작...');

// package.json에 pkg 설정 추가
const packageJson = JSON.parse(fs.readFileSync('package.json', 'utf8'));
packageJson.bin = './server.js';
packageJson.pkg = {
  scripts: ['server.js'],
  assets: ['package.json'],
  targets: ['node18-win-x64'],
  outputPath: 'dist'
};

// 개발 의존성에 pkg 추가
packageJson.devDependencies = packageJson.devDependencies || {};
packageJson.devDependencies.pkg = '^5.8.1';

fs.writeFileSync('package.json', JSON.stringify(packageJson, null, 2));

console.log('📦 package.json 업데이트 완료');

// pkg 설치 및 빌드
exec('npm install pkg --save-dev', (error, stdout, stderr) => {
  if (error) {
    console.error('❌ pkg 설치 실패:', error);
    return;
  }
  
  console.log('✅ pkg 설치 완료');
  console.log('🔨 EXE 파일 생성 중...');
  
  exec('npx pkg . --target node18-win-x64 --output dist/naver-proxy-server.exe', (error, stdout, stderr) => {
    if (error) {
      console.error('❌ EXE 빌드 실패:', error);
      return;
    }
    
    console.log('✅ EXE 파일 생성 완료!');
    console.log('📁 경로: dist/naver-proxy-server.exe');
    console.log(stdout);
  });
});