# 네이버 블로그 순위 체크용 프록시 서버

## 🚀 빠른 시작

```bash
# 의존성 설치
npm install

# 서버 실행
npm start
```

## 📊 성능 특징

- **캐싱**: 5분간 결과 캐싱으로 동일 검색 즉시 반환
- **Keep-Alive**: 연결 재사용으로 속도 향상
- **최적화된 헤더**: 네이버 검색에 특화된 헤더 설정
- **배치 처리**: 여러 URL 동시 처리 지원

## 🔧 API 엔드포인트

### 단일 프록시 요청
```
GET /proxy?url=https://search.naver.com/search.naver?where=blog&query=키워드
```

### 배치 처리
```
POST /proxy/batch
Content-Type: application/json

{
  "urls": [
    "https://search.naver.com/search.naver?where=blog&query=키워드1",
    "https://search.naver.com/search.naver?where=blog&query=키워드2"
  ]
}
```

### 서버 상태 확인
```
GET /health
GET /cache/stats
```

## 💡 사용 방법

1. 이 서버를 실행
2. 프론트엔드에서 '자체 프록시 서버' 선택
3. 훨씬 빠른 속도로 블로그 순위 체크!