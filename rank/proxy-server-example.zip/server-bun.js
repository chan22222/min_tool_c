// Bun으로 실행 가능한 단일 파일 프록시 서버
const port = process.env.PORT || 3002;
const server = Bun.serve({
  port: port,
  async fetch(req) {
    const url = new URL(req.url);
    
    // CORS 헤더 설정
    const corsHeaders = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    };

    // OPTIONS 요청 처리
    if (req.method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders });
    }

    // 프록시 요청 처리
    if (url.pathname === '/proxy') {
      const targetUrl = url.searchParams.get('url');
      
      if (!targetUrl) {
        return new Response(JSON.stringify({ error: 'URL parameter required' }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      try {
        const startTime = Date.now();
        console.log(`🔍 프록시 요청: ${targetUrl.substring(0, 50)}...`);
        
        const response = await fetch(targetUrl, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7',
            'Accept-Encoding': 'gzip, deflate, br',
            'Referer': 'https://search.naver.com/',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'cross-site',
            'Cache-Control': 'max-age=0'
          },
          signal: AbortSignal.timeout(15000) // 15초 타임아웃
        });

        const html = await response.text();
        
        return new Response(html, {
          headers: { 
            ...corsHeaders, 
            'Content-Type': 'text/html; charset=utf-8',
            'X-Proxy-Server': 'Bun-Proxy',
            'X-Response-Time': `${Date.now() - startTime}ms`
          }
        });
        
      } catch (error) {
        console.error('❌ 프록시 에러:', error.message);
        return new Response(JSON.stringify({ 
          error: 'Proxy request failed', 
          details: error.message 
        }), {
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
    }

    // 배치 처리 엔드포인트 (여러 URL 동시 처리) - Node.js와 동일한 성능
    if (url.pathname === '/proxy/batch' && req.method === 'POST') {
      try {
        const body = await req.json();
        const { urls } = body;
        
        if (!Array.isArray(urls) || urls.length === 0) {
          return new Response(JSON.stringify({ error: 'URLs array is required' }), {
            status: 400,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
          });
        }

        if (urls.length > 10) {
          return new Response(JSON.stringify({ error: 'Too many URLs. Maximum 10 allowed.' }), {
            status: 400,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
          });
        }

        console.log(`🔄 Bun 배치 처리: ${urls.length}개 URL`);

        const promises = urls.map(async (targetUrl, index) => {
          try {
            console.log(`🔍 배치 [${index + 1}/${urls.length}]: ${targetUrl.substring(0, 50)}...`);
            
            const response = await fetch(targetUrl, {
              headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7',
                'Accept-Encoding': 'gzip, deflate, br',
                'Referer': 'https://search.naver.com/',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
                'Sec-Fetch-Dest': 'document',
                'Sec-Fetch-Mode': 'navigate',
                'Sec-Fetch-Site': 'cross-site',
                'Cache-Control': 'max-age=0'
              },
              signal: AbortSignal.timeout(15000)
            });

            const html = await response.text();
            return { index, success: true, data: html };
            
          } catch (error) {
            console.error(`❌ 배치 [${index + 1}] 에러:`, error.message);
            return { 
              index, 
              success: false, 
              error: error.message,
              status: error.status 
            };
          }
        });

        const results = await Promise.all(promises);
        
        const successCount = results.filter(r => r.success).length;
        console.log(`✅ Bun 배치 완료: ${successCount}/${urls.length} 성공`);
        
        return new Response(JSON.stringify({ 
          results, 
          summary: { 
            total: urls.length, 
            success: successCount, 
            failed: urls.length - successCount 
          }
        }), {
          headers: { 
            ...corsHeaders, 
            'Content-Type': 'application/json',
            'X-Proxy-Server': 'Bun-Batch-Proxy'
          }
        });
        
      } catch (error) {
        console.error('❌ Bun 배치 처리 에러:', error.message);
        return new Response(JSON.stringify({ 
          error: 'Batch processing failed', 
          details: error.message 
        }), {
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
    }

    // 상태 확인
    if (url.pathname === '/health') {
      return new Response(JSON.stringify({ 
        status: 'healthy', 
        timestamp: new Date().toISOString(),
        server: 'Bun'
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // 기본 응답
    return new Response(`
      <html>
        <head><title>네이버 블로그 프록시 서버</title></head>
        <body style="font-family: Arial; padding: 20px; background: #f5f5f5;">
          <h1>🚀 네이버 블로그 프록시 서버</h1>
          <p>✅ 서버가 정상 작동 중입니다.</p>
          <p>📍 프록시 엔드포인트: <code>/proxy?url=...</code></p>
          <p>🚀 배치 처리: <code>POST /proxy/batch</code> (병렬 처리 지원)</p>
          <p>📊 상태 확인: <code>/health</code></p>
          <hr>
          <p>💡 이 서버를 프론트엔드에서 '자체 프록시 서버'로 선택하세요.</p>
          <p>🔥 Bun 기반 고성능 병렬 처리로 Node.js와 동등한 성능!</p>
        </body>
      </html>
    `, {
      headers: { ...corsHeaders, 'Content-Type': 'text/html' }
    });
  }
});

console.log(`🚀 네이버 블로그 프록시 서버가 http://localhost:${server.port} 에서 실행 중입니다`);
console.log(`📊 상태 확인: http://localhost:${server.port}/health`);
console.log(`💻 Bun 기반 고성능 서버`);
console.log(`🔗 프록시 URL: http://localhost:${server.port}/proxy?url=`);