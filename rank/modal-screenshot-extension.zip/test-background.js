// 간단한 테스트용 - Modal Body Screenshot
console.log('🧪 Simple Modal Screenshot Test Extension Loaded');

// 키보드 단축키 처리
chrome.commands.onCommand.addListener(async (command) => {
  console.log('🔥 Command triggered:', command);
  
  if (command === 'capture-modal') {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      console.log('📱 Active tab:', tab.id);
      
      // 즉시 화면 캡처 시도
      const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, {
        format: 'png',
        quality: 100
      });
      
      console.log('📸 Screenshot captured, size:', dataUrl.length);
      
      // 간단한 파일명 생성
      const timestamp = Date.now();
      const filename = `modal-test-${timestamp}.png`;
      
      // 다운로드
      const downloadId = await chrome.downloads.download({
        url: dataUrl,
        filename: filename,
        saveAs: false
      });
      
      console.log('💾 Download started, ID:', downloadId);
      
      // 성공 알림을 위해 content script에 메시지
      chrome.tabs.sendMessage(tab.id, {
        action: 'showSuccess',
        message: `✅ Screenshot saved as ${filename}`
      }).catch(e => {
        console.log('Content script message failed (normal):', e.message);
      });
      
    } catch (error) {
      console.error('💥 Capture failed:', error);
    }
  }
});

console.log('🎯 Test extension ready for Ctrl+Q');
