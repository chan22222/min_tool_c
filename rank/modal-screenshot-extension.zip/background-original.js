// Modal Body Screenshot - Background Service Worker
console.log('🎯 Modal Body Screenshot Extension Started');

// 키보드 단축키 처리
chrome.commands.onCommand.addListener(async (command) => {
  console.log('📋 Command received:', command);
  
  if (command === 'capture-modal') {
    console.log('📸 Starting modal-body capture...');
    
    try {
      // 현재 활성 탭 가져오기
      const [tab] = await chrome.tabs.query({ 
        active: true, 
        currentWindow: true 
      });
      
      if (!tab) {
        console.error('❌ No active tab found');
        return;
      }
      
      console.log('🎯 Active tab:', tab.id, tab.url);
      
      // Content script 없이 직접 화면 캡처
      await captureDirectly(tab);
      
    } catch (error) {
      console.error('💥 Capture command error:', error);
    }
  }
});

// Content script 없이 직접 캡처
async function captureDirectly(tab) {
  try {
    console.log('📷 Starting smart modal capture...');
    
    // Content script에 modal-body 정보 요청
    let modalInfo = null;
    try {
      console.log('📡 Requesting modal info from content script...');
      modalInfo = await chrome.tabs.sendMessage(tab.id, {
        action: 'getModalInfo'
      });
      console.log('📍 Modal info received:', modalInfo);
      
      // 오류가 있으면 fallback 사용
      if (modalInfo && modalInfo.error) {
        console.log('⚠️ Modal info has error, using fallback:', modalInfo.error);
        modalInfo = null;
      }
    } catch (e) {
      console.log('📱 Content script not available, using fallback:', e.message);
      modalInfo = null;
    }
    
    // 전체 화면 캡처
    const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, {
      format: 'png',
      quality: 100
    });
    
    console.log('📸 Screenshot captured, size:', Math.round(dataUrl.length / 1024) + 'KB');
    
    // 파일명 생성 (키워드 기반)
    let filename;
    if (modalInfo && modalInfo.keyword) {
      const safeKeyword = modalInfo.keyword
        .replace(/[<>:"/\\|?*]/g, '_')
        .replace(/\s+/g, '_')
        .substring(0, 50); // 최대 50자
      filename = `${safeKeyword}_screenshot.png`;
    } else {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-').split('T')[0] + '_' + 
                       new Date().toTimeString().split(' ')[0].replace(/:/g, '-');
      filename = `modal-screenshot-${timestamp}.png`;
    }
    
    // modal-body가 있으면 크롭핑, 없으면 전체 저장
    let finalDataUrl = dataUrl;
    if (modalInfo && modalInfo.bounds) {
      try {
        finalDataUrl = await cropImage(dataUrl, modalInfo.bounds);
        console.log('✂️ Image cropped to modal-body');
      } catch (cropError) {
        console.log('⚠️ Cropping failed, saving full image:', cropError.message);
      }
    }
    
    // 다운로드
    const downloadId = await chrome.downloads.download({
      url: finalDataUrl,
      filename: filename,
      saveAs: false,
      conflictAction: 'uniquify'
    });
    
    console.log('💾 Download started, ID:', downloadId, 'File:', filename);
    
    // 성공 메시지 전송
    try {
      await chrome.tabs.sendMessage(tab.id, {
        action: 'showNotification',
        message: `✅ Screenshot saved: ${filename}`
      });
    } catch (e) {
      console.log('📱 Notification failed (normal)');
    }
    
    console.log('✅ Smart capture completed successfully');
    
  } catch (error) {
    console.error('💥 Smart capture failed:', error);
    throw error;
  }
}

// Content script로부터 캡처 데이터 수신
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('📨 Background received message:', message.action);
  
  if (message.action === 'downloadScreenshot') {
    downloadScreenshot(message.dataUrl, message.filename)
      .then(() => {
        console.log('✅ Download successful');
        sendResponse({ success: true });
      })
      .catch(error => {
        console.error('❌ Download failed:', error);
        sendResponse({ success: false, error: error.message });
      });
    
    return true; // 비동기 응답
  }
  
  // 좌표 기반 캡처 처리 추가
  if (message.action === 'captureWithCoordinates') {
    captureVisibleTabAndCrop(message.captureInfo, sender.tab.id)
      .then(() => {
        console.log('✅ Coordinate capture successful');
        sendResponse({ success: true });
      })
      .catch(error => {
        console.error('❌ Coordinate capture failed:', error);
        sendResponse({ success: false, error: error.message });
      });
    
    return true; // 비동기 응답
  }
});

// 이미지 크롭핑 함수 (Content script 위임)
async function cropImage(dataUrl, bounds) {
  try {
    console.log('✂️ Requesting crop from content script...');
    
    // Content script에 크롭핑 요청
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    const response = await chrome.tabs.sendMessage(tab.id, {
      action: 'cropImage',
      dataUrl: dataUrl,
      bounds: bounds
    });
    
    if (response && response.success) {
      console.log('✅ Image cropped successfully');
      return response.croppedDataUrl;
    } else {
      throw new Error('Cropping failed: ' + (response?.error || 'Unknown error'));
    }
    
  } catch (error) {
    console.error('💥 Cropping failed:', error);
    throw error;
  }
}
async function downloadScreenshot(dataUrl, filename) {
  try {
    console.log('💾 Downloading screenshot:', filename);
    
    // 파일명에 안전하지 않은 문자 제거
    const safeFilename = filename.replace(/[<>:"/\\|?*]/g, '_');
    
    const downloadId = await chrome.downloads.download({
      url: dataUrl,
      filename: safeFilename,
      saveAs: false,
      conflictAction: 'uniquify'
    });
    
    console.log('📥 Screenshot download started, ID:', downloadId);
    
    // 다운로드 완료 대기
    return new Promise((resolve, reject) => {
      const onChanged = (downloadDelta) => {
        if (downloadDelta.id === downloadId && downloadDelta.state) {
          if (downloadDelta.state.current === 'complete') {
            chrome.downloads.onChanged.removeListener(onChanged);
            console.log('✅ Download completed successfully');
            resolve();
          } else if (downloadDelta.state.current === 'interrupted') {
            chrome.downloads.onChanged.removeListener(onChanged);
            reject(new Error('Download was interrupted'));
          }
        }
      };
      
      chrome.downloads.onChanged.addListener(onChanged);
      
      // 10초 타임아웃
      setTimeout(() => {
        chrome.downloads.onChanged.removeListener(onChanged);
        resolve(); // 타임아웃이어도 성공으로 처리
      }, 10000);
    });
    
  } catch (error) {
    console.error('💥 Download error:', error);
    throw error;
  }
}

// 좌표 기반 캡처 및 크롭
async function captureVisibleTabAndCrop(captureInfo, tabId) {
  try {
    console.log('📐 Coordinate-based capture starting...');
    
    // 전체 화면 캡처
    const dataUrl = await chrome.tabs.captureVisibleTab(null, {
      format: 'png',
      quality: 100
    });
    
    console.log('📸 Full screen captured, now cropping...');
    
    // 크롭핑을 위해 content script에 전송
    const response = await chrome.tabs.sendMessage(tabId, {
      action: 'cropImage',
      dataUrl: dataUrl,
      cropInfo: captureInfo
    });
    
    if (response && response.success) {
      // 크롭된 이미지 다운로드
      await downloadScreenshot(response.croppedDataUrl, captureInfo.filename);
      console.log('✅ Cropped image downloaded');
    } else {
      throw new Error('Image cropping failed');
    }
    
  } catch (error) {
    console.error('💥 Coordinate capture error:', error);
    throw error;
  }
}
