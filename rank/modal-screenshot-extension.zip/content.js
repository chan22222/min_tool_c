// 초간단 Content Script - 확실한 크롭핑
console.log('🔥🔥🔥 SIMPLE CONTENT SCRIPT LOADED 🔥🔥🔥');

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('🔥 SIMPLE CONTENT MESSAGE RECEIVED:', message.action);
  
  if (message.action === 'SIMPLE_CROP') {
    console.log('🔥 STARTING SIMPLE CROP OPERATION...');
    
    try {
      // 1. 키워드 찾기
      let keyword = 'TEST';
      try {
        // 여러 위치에서 키워드 찾기 시도
        const headerElement = document.querySelector('.control-panel-header') ||      // 새로운 컨트롤 패널
                             document.querySelector('.modal-control-panel') ||        // 대체 컨트롤 패널
                             document.querySelector('.modal-header') ||               // 기존 모달 헤더
                             document.querySelector('.fixed-search-area input') ||    // 검색창 input
                             document.querySelector('input[type="text"]') ||          // 일반 input
                             document.querySelector('h3') ||
                             document.querySelector('h2');
        
        if (headerElement) {
          // input 요소인 경우
          if (headerElement.tagName === 'INPUT') {
            keyword = headerElement.value.trim() || 'TEST';
            console.log('🎯 KEYWORD FROM INPUT:', keyword);
          } else {
            // 텍스트 요소인 경우
            const text = headerElement.textContent || headerElement.innerText || '';
            console.log('📄 Header text found:', text);
            
            const match = text.match(/"([^"]+)"/) || text.match(/:\s*"([^"]+)"/) || text.match(/:\s*([^\s]+)/);
            if (match && match[1]) {
              keyword = match[1].trim();
              console.log('🎯 KEYWORD EXTRACTED:', keyword);
            }
          }
        }
      } catch (keywordError) {
        console.log('⚠️ Keyword extraction failed:', keywordError.message);
      }
      
      // 2. Modal body 찾기 (여러 셀렉터 시도)
      const selectors = [
        '.modal-body',
        '#contentFrame', 
        '.search-preview-modal .modal-body',
        '.search-preview-modal iframe',
        '.search-preview-modal'
      ];
      
      let modalElement = null;
      let usedSelector = '';
      
      for (const selector of selectors) {
        const element = document.querySelector(selector);
        if (element) {
          const rect = element.getBoundingClientRect();
          console.log(`🔍 Found element "${selector}":`, rect);
          
          if (rect.width > 100 && rect.height > 100) {
            modalElement = element;
            usedSelector = selector;
            console.log(`✅ SELECTED: ${selector} (${rect.width}x${rect.height})`);
            break;
          }
        }
      }
      
      if (!modalElement) {
        console.log('❌ NO SUITABLE MODAL ELEMENT FOUND');
        sendResponse({ 
          success: false, 
          error: 'No suitable modal element found',
          keyword: keyword 
        });
        return false;
      }
      
      const rect = modalElement.getBoundingClientRect();
      console.log('🎯 FINAL MODAL BOUNDS:', rect);
      
      // 3. 크롭핑 실행
      console.log('🔨 STARTING CROP OPERATION...');
      
      const img = new Image();
      img.onload = () => {
        try {
          console.log('🖼️ Image loaded for cropping');
          
          const canvas = document.createElement('canvas');
          const ctx = canvas.getContext('2d');
          
          // Canvas 크기 설정
          canvas.width = rect.width;
          canvas.height = rect.height;
          
          console.log('🎨 Canvas created:', canvas.width, 'x', canvas.height);
          
          // 흰색 배경 설정
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, rect.width, rect.height);
          
          // 이미지 크롭핑
          ctx.drawImage(
            img,
            rect.x, rect.y, rect.width, rect.height,  // 소스
            0, 0, rect.width, rect.height             // 대상
          );
          
          const croppedDataUrl = canvas.toDataURL('image/png', 1.0);
          
          console.log('✅ CROP SUCCESS!');
          console.log('📊 Original size:', Math.round(message.dataUrl.length / 1024), 'KB');
          console.log('📊 Cropped size:', Math.round(croppedDataUrl.length / 1024), 'KB');
          
          sendResponse({
            success: true,
            croppedDataUrl: croppedDataUrl,
            keyword: keyword,
            bounds: rect,
            selector: usedSelector
          });
          
        } catch (cropError) {
          console.log('❌ CROP OPERATION FAILED:', cropError);
          sendResponse({ 
            success: false, 
            error: cropError.message,
            keyword: keyword 
          });
        }
      };
      
      img.onerror = (error) => {
        console.log('❌ IMAGE LOAD FAILED:', error);
        sendResponse({ 
          success: false, 
          error: 'Image load failed',
          keyword: keyword 
        });
      };
      
      console.log('📥 Loading image data...');
      img.src = message.dataUrl;
      
    } catch (mainError) {
      console.log('❌ MAIN CROP ERROR:', mainError);
      sendResponse({ 
        success: false, 
        error: mainError.message,
        keyword: 'ERROR' 
      });
    }
    
    return true; // 비동기 응답 대기
  }
  
  if (message.action === 'SHOW_RESULT') {
    console.log('📢 Showing result notification:', message.message);
    
    const toast = document.createElement('div');
    toast.style.cssText = `
      position: fixed !important;
      top: 20px !important;
      right: 20px !important;
      background: #28a745 !important;
      color: white !important;
      padding: 15px 20px !important;
      border-radius: 8px !important;
      z-index: 999999 !important;
      font-family: 'Arial', sans-serif !important;
      font-size: 14px !important;
      font-weight: bold !important;
      max-width: 400px !important;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3) !important;
    `;
    toast.textContent = message.message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
      if (toast.parentNode) {
        toast.remove();
      }
    }, 5000);
    
    sendResponse({ success: true });
    return false;
  }
  
  return false;
});

console.log('🔥 SIMPLE CONTENT SCRIPT READY AND WAITING...');
