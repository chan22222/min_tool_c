// 간단한 스크린샷 확장프로그램
console.log('📸 Screenshot Extension Loaded');

// 키보드 단축키 처리
chrome.commands.onCommand.addListener(async (command) => {
  if (command === 'capture-modal') {
    await captureScreenshot();
  }
});

// 확장프로그램 아이콘 클릭
chrome.action.onClicked.addListener(async () => {
  await captureScreenshot();
});

// 메시지 처리 (팝업에서 요청)
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'capture') {
    captureScreenshot().then(() => {
      sendResponse({success: true});
    });
    return true;
  }
});

// 스크린샷 캡처 함수
async function captureScreenshot() {
  try {
    console.log('🎯 Starting capture...');
    
    // 현재 탭 가져오기
    const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
    
    // 전체 화면 캡처
    const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, {
      format: 'png',
      quality: 100
    });
    
    // 크롭 시도
    let filename = 'screenshot_' + Date.now() + '.png';
    let finalDataUrl = dataUrl;
    
    try {
      // Content script 주입하여 크롭
      const results = await chrome.scripting.executeScript({
        target: {tabId: tab.id},
        func: cropModalFunction,
        args: [dataUrl]
      });
      
      if (results && results[0] && results[0].result) {
        const result = results[0].result;
        if (result.success && result.dataUrl) {
          finalDataUrl = result.dataUrl;
          filename = (result.keyword || 'modal') + '_screenshot.png';
          console.log('✅ Cropped successfully:', filename);
        }
      }
    } catch (e) {
      console.log('⚠️ Crop failed, using full screenshot:', e.message);
    }
    
    // 다운로드
    await chrome.downloads.download({
      url: finalDataUrl,
      filename: filename,
      saveAs: false
    });
    
    console.log('✅ Downloaded:', filename);
    
  } catch (error) {
    console.error('❌ Capture failed:', error);
  }
}

// 페이지에 주입될 크롭 함수
function cropModalFunction(dataUrl) {
  try {
    // 키워드 찾기
    let keyword = 'modal';
    const headerElement = document.querySelector('.control-panel-header') ||
                         document.querySelector('.modal-control-panel') ||
                         document.querySelector('input[type="text"]') ||
                         document.querySelector('h3');
    
    if (headerElement) {
      if (headerElement.tagName === 'INPUT') {
        keyword = headerElement.value.trim() || 'modal';
      } else {
        const text = headerElement.textContent || '';
        const match = text.match(/"([^"]+)"/) || text.match(/:\s*([^\s]+)/);
        if (match) keyword = match[1];
      }
    }
    
    // 모달 찾기
    const modalElement = document.querySelector('.modal-body') ||
                        document.querySelector('#contentFrame') ||
                        document.querySelector('.search-preview-modal') ||
                        document.querySelector('.modal-content');
    
    if (!modalElement) {
      return {success: false, error: 'No modal found'};
    }
    
    const rect = modalElement.getBoundingClientRect();
    
    // 캔버스 생성 및 크롭
    const img = new Image();
    
    return new Promise((resolve) => {
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        
        canvas.width = rect.width;
        canvas.height = rect.height;
        
        ctx.drawImage(img, 
          rect.x, rect.y, rect.width, rect.height,
          0, 0, rect.width, rect.height
        );
        
        resolve({
          success: true,
          dataUrl: canvas.toDataURL('image/png'),
          keyword: keyword
        });
      };
      
      img.onerror = () => {
        resolve({success: false, error: 'Image load failed'});
      };
      
      img.src = dataUrl;
    });
    
  } catch (error) {
    return {success: false, error: error.message};
  }
}
