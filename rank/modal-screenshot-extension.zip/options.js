document.addEventListener('DOMContentLoaded', async () => {
  
  // 현재 단축키 표시
  async function updateShortcut() {
    try {
      const commands = await chrome.commands.getAll();
      const cmd = commands.find(c => c.name === 'capture-modal');
      
      const element = document.getElementById('currentShortcut');
      if (cmd && cmd.shortcut) {
        element.textContent = cmd.shortcut;
      } else {
        element.textContent = '설정되지 않음';
        element.style.color = '#dc3545';
      }
    } catch (e) {
      console.error(e);
    }
  }
  
  updateShortcut();
  
  // 단축키 변경 버튼
  document.getElementById('changeBtn').addEventListener('click', () => {
    chrome.tabs.create({
      url: 'chrome://extensions/shortcuts'
    });
  });
  
  // 추천 단축키 클릭
  document.querySelectorAll('.shortcut-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      const key = chip.textContent;
      navigator.clipboard.writeText(key);
      
      // 피드백
      chip.style.background = '#28a745';
      chip.style.color = 'white';
      chip.textContent = '✓ 복사됨';
      
      setTimeout(() => {
        chip.style.background = '';
        chip.style.color = '';
        chip.textContent = key;
      }, 1500);
    });
  });
  
  // 2초마다 업데이트
  setInterval(updateShortcut, 2000);
  
});