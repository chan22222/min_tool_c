// 초간단 테스트 버전 - 확실한 크롭핑
console.log('🔥 Ultra Simple Test Extension');

chrome.commands.onCommand.addListener(async (command) => {
  if (command === 'capture-modal') {
    console.log('🔥 SIMPLE TEST START');
    
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      // 1. 일단 전체 캡처
      const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, {
        format: 'png',
        quality: 100
      });
      
      console.log('📸 Full screenshot captured');
      
      // 2. Content script에서 modal 정보 요청 (타임아웃 2초)
      let cropResult = null;
      try {
        console.log('📡 Requesting modal crop...');
        
        cropResult = await Promise.race([
          chrome.tabs.sendMessage(tab.id, {
            action: 'SIMPLE_CROP',
            dataUrl: dataUrl
          }),
          new Promise((_, reject) => 
            setTimeout(() => reject(new Error('2초 타임아웃')), 2000)
          )
        ]);
        
        console.log('✅ Crop result:', cropResult ? 'SUCCESS' : 'FAILED');
        
      } catch (e) {
        console.log('❌ Content script failed:', e.message);
      }
      
      // 3. 파일명 및 데이터 결정
      let finalDataUrl = dataUrl;
      let filename = 'FULL_SCREEN.png';
      
      if (cropResult && cropResult.success) {
        finalDataUrl = cropResult.croppedDataUrl;
        filename = `CROPPED_${cropResult.keyword || 'TEST'}.png`;
        console.log('✂️ Using cropped version');
      } else {
        console.log('📺 Using full screen version');
      }
      
      // 4. 다운로드
      const downloadId = await chrome.downloads.download({
        url: finalDataUrl,
        filename: filename,
        saveAs: false
      });
      
      console.log('💾 Download completed:', filename);
      
      // 5. 알림
      try {
        chrome.tabs.sendMessage(tab.id, {
          action: 'SHOW_RESULT',
          message: `✅ ${filename} (${cropResult ? 'CROPPED' : 'FULL'})`
        });
      } catch (e) {}
      
    } catch (error) {
      console.error('💥 Test failed:', error);
    }
  }
});
