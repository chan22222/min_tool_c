// 초간단 Content Script
console.log('🔥 SIMPLE CONTENT LOADED');

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('🔥 SIMPLE MESSAGE:', message.action);
  
  if (message.action === 'SIMPLE_CROP') {
    console.log('🔥 STARTING SIMPLE CROP');
    
    try {
      // 1. 키워드 찾기
      let keyword = 'TEST';
      const headerElement = document.querySelector('.modal-header h3') || 
                           document.querySelector('h3');
      
      if (headerElement) {
        const text = headerElement.textContent || '';
        const match = text.match(/"([^"]+)"/);
        if (match) {
          keyword = match[1];
          console.log('🔥 KEYWORD FOUND:', keyword);
        }
      }
      
      // 2. Modal body 찾기
      const modalBody = document.querySelector('.modal-body') || 
                       document.querySelector('#contentFrame') ||
                       document.querySelector('.search-preview-modal');
      
      if (!modalBody) {
        console.log('❌ NO MODAL FOUND');
        sendResponse({ success: false, error: 'No modal found' });
        return;
      }
      
      const rect = modalBody.getBoundingClientRect();
      console.log('🔥 MODAL BOUNDS:', rect);
      
      if (rect.width < 100 || rect.height < 100) {
        console.log('❌ MODAL TOO SMALL');
        sendResponse({ success: false, error: 'Modal too small' });
        return;
      }
      
      // 3. 크롭핑 실행
      console.log('🔥 STARTING CROP OPERATION');
      
      const img = new Image();
      img.onload = () => {
        try {
          const canvas = document.createElement('canvas');
          const ctx = canvas.getContext('2d');
          
          canvas.width = rect.width;
          canvas.height = rect.height;
          
          // 흰색 배경
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, rect.width, rect.height);
          
          // 이미지 크롭
          ctx.drawImage(
            img,
            rect.x, rect.y, rect.width, rect.height,
            0, 0, rect.width, rect.height
          );
          
          const croppedDataUrl = canvas.toDataURL('image/png', 1.0);
          
          console.log('🔥 CROP SUCCESS:', Math.round(croppedDataUrl.length / 1024), 'KB');
          
          sendResponse({
            success: true,
            croppedDataUrl: croppedDataUrl,
            keyword: keyword,
            bounds: rect
          });
          
        } catch (error) {
          console.log('❌ CROP FAILED:', error);
          sendResponse({ success: false, error: error.message });
        }
      };
      
      img.onerror = () => {
        console.log('❌ IMAGE LOAD FAILED');
        sendResponse({ success: false, error: 'Image load failed' });
      };
      
      img.src = message.dataUrl;
      
    } catch (error) {
      console.log('❌ SIMPLE CROP ERROR:', error);
      sendResponse({ success: false, error: error.message });
    }
    
    return true; // 비동기 응답
  }
  
  if (message.action === 'SHOW_RESULT') {
    const toast = document.createElement('div');
    toast.style.cssText = `
      position: fixed !important;
      top: 20px !important;
      right: 20px !important;
      background: #28a745 !important;
      color: white !important;
      padding: 15px !important;
      border-radius: 8px !important;
      z-index: 999999 !important;
      font-family: Arial !important;
      font-size: 14px !important;
      font-weight: bold !important;
      max-width: 300px !important;
    `;
    toast.textContent = message.message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
      if (toast.parentNode) toast.remove();
    }, 5000);
    
    sendResponse({ success: true });
  }
  
  return false;
});

console.log('🔥 SIMPLE CONTENT READY');
