// Modal Body Screenshot - Simple Content Script
console.log('🎯 Simple Modal Screenshot Content Script Loaded');

// Background에서 메시지 수신
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('📨 Content received:', message.action);
  
  if (message.action === 'showNotification') {
    showNotification(message.message);
    sendResponse({ success: true });
    return false; // 동기 응답
  }
  
  if (message.action === 'getModalInfo') {
    try {
      const modalInfo = getModalBodyInfo();
      console.log('📍 Sending modal info:', modalInfo);
      sendResponse(modalInfo);
      return false; // 동기 응답
    } catch (error) {
      console.error('❌ Failed to get modal info:', error);
      sendResponse({ error: error.message });
      return false; // 동기 응답
    }
  }
  
  if (message.action === 'cropImage') {
    console.log('✂️ Starting crop operation...');
    cropImageInContent(message.dataUrl, message.bounds)
      .then(croppedDataUrl => {
        console.log('✂️ Image cropped in content script');
        sendResponse({ success: true, croppedDataUrl: croppedDataUrl });
      })
      .catch(error => {
        console.error('❌ Content cropping failed:', error);
        sendResponse({ success: false, error: error.message });
      });
    return true; // 비동기 응답
  }
  
  return false;
});

// Modal-body 정보 추출 함수
function getModalBodyInfo() {
  try {
    console.log('🔍 Looking for modal elements...');
    
    // 1. 키워드 추출 (modal-header에서)
    let keyword = 'screenshot';
    const headerSelectors = [
      '.modal-header h3',
      '.modal-header h2', 
      '.modal-header h1',
      '.modal-header .modal-title',
      '.search-preview-modal .modal-header h3',
      '.search-preview-modal h3'
    ];
    
    for (const selector of headerSelectors) {
      const headerElement = document.querySelector(selector);
      if (headerElement) {
        const text = headerElement.textContent || headerElement.innerText || '';
        console.log('📄 Found header text:', text);
        
        // "검색결과 : 키워드" 형태에서 키워드 추출
        const match = text.match(/검색결과\s*:\s*"?([^"]+)"?/i) || 
                     text.match(/결과\s*:\s*"?([^"]+)"?/i) ||
                     text.match(/"([^"]+)"/);
        
        if (match && match[1]) {
          keyword = match[1].trim();
          console.log('🎯 Extracted keyword:', keyword);
          break;
        }
      }
    }
    
    // 2. Modal-body 요소 찾기 및 좌표 추출
    const modalSelectors = [
      '.modal-body',                                    // 일반적인 modal body
      '.search-preview-modal .modal-body',             // 검색 모달의 body
      '#contentFrame',                                 // iframe 컨테이너
      '.search-preview-modal iframe',                  // 모달 안의 iframe
      '.search-preview-modal .content-frame',          // 커스텀 컨테이너
      '.modal-content .modal-body',                    // Bootstrap 스타일
      '.modal-dialog .modal-body'                      // 중첩된 modal
    ];
    
    let targetElement = null;
    let selectorUsed = '';
    
    for (const selector of modalSelectors) {
      const elements = document.querySelectorAll(selector);
      console.log(`🔍 Checking selector "${selector}": found ${elements.length} elements`);
      
      for (const element of elements) {
        const rect = element.getBoundingClientRect();
        console.log(`📐 Element rect:`, rect);
        
        // 보이는 요소만 선택 (width, height > 50px)
        if (rect.width > 50 && rect.height > 50) {
          targetElement = element;
          selectorUsed = selector;
          console.log(`✅ Selected element with selector: ${selector}`);
          break;
        }
      }
      
      if (targetElement) break;
    }
    
    if (!targetElement) {
      console.log('⚠️ No suitable modal element found, trying fallback...');
      
      // Fallback: 모든 modal 관련 요소 검색
      const fallbackSelectors = [
        '.search-preview-modal',
        '.modal',
        '.modal-dialog',
        '.modal-content'
      ];
      
      for (const selector of fallbackSelectors) {
        const element = document.querySelector(selector);
        if (element) {
          const rect = element.getBoundingClientRect();
          if (rect.width > 200 && rect.height > 200) {
            targetElement = element;
            selectorUsed = selector + ' (fallback)';
            console.log(`🔄 Using fallback selector: ${selector}`);
            break;
          }
        }
      }
    }
    
    if (!targetElement) {
      console.log('❌ Absolutely no modal element found');
      return { keyword, error: 'No modal element found at all' };
    }
    
    // 3. 요소 좌표 계산
    const rect = targetElement.getBoundingClientRect();
    const bounds = {
      x: Math.round(rect.x),
      y: Math.round(rect.y),
      width: Math.round(rect.width),
      height: Math.round(rect.height)
    };
    
    console.log('📐 Modal bounds:', bounds);
    
    // 4. 요소가 보이는지 확인
    if (bounds.width === 0 || bounds.height === 0) {
      console.log('⚠️ Modal element is not visible');
      return { keyword, error: 'Modal element not visible' };
    }
    
    return {
      keyword: keyword,
      bounds: bounds,
      selector: selectorUsed,
      visible: true
    };
    
  } catch (error) {
    console.error('💥 Error getting modal info:', error);
    return { 
      keyword: 'screenshot',
      error: error.message 
    };
  }
}

// Content Script에서 이미지 크롭핑
async function cropImageInContent(dataUrl, bounds) {
  return new Promise((resolve, reject) => {
    try {
      console.log('✂️ Cropping in content script:', bounds);
      
      const img = new Image();
      img.onload = () => {
        try {
          const canvas = document.createElement('canvas');
          const ctx = canvas.getContext('2d');
          
          // Canvas 크기 설정
          canvas.width = bounds.width;
          canvas.height = bounds.height;
          
          // 이미지 크롭핑
          ctx.drawImage(
            img,
            bounds.x, bounds.y, bounds.width, bounds.height,
            0, 0, bounds.width, bounds.height
          );
          
          // 고품질 PNG로 변환
          const croppedDataUrl = canvas.toDataURL('image/png', 1.0);
          
          console.log('✅ Cropping completed, new size:', Math.round(croppedDataUrl.length / 1024) + 'KB');
          resolve(croppedDataUrl);
          
        } catch (canvasError) {
          console.error('Canvas error:', canvasError);
          reject(canvasError);
        }
      };
      
      img.onerror = () => reject(new Error('Failed to load image'));
      img.src = dataUrl;
      
    } catch (error) {
      console.error('Crop setup error:', error);
      reject(error);
    }
  });
}

// 알림 표시 함수
function showNotification(message) {
  try {
    // 기존 알림 제거
    const existingToast = document.querySelector('#modal-capture-toast');
    if (existingToast) {
      existingToast.remove();
    }
    
    // 새 알림 생성
    const toast = document.createElement('div');
    toast.id = 'modal-capture-toast';
    toast.style.cssText = `
      position: fixed !important;
      top: 20px !important;
      right: 20px !important;
      background: #28a745 !important;
      color: white !important;
      padding: 12px 20px !important;
      border-radius: 6px !important;
      z-index: 999999 !important;
      font-family: Arial, sans-serif !important;
      font-size: 14px !important;
      font-weight: bold !important;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3) !important;
      animation: slideInRight 0.3s ease-out !important;
      max-width: 300px !important;
      word-wrap: break-word !important;
    `;
    
    toast.textContent = message;
    document.body.appendChild(toast);
    
    // 애니메이션 CSS 추가
    if (!document.querySelector('#modal-capture-styles')) {
      const style = document.createElement('style');
      style.id = 'modal-capture-styles';
      style.textContent = `
        @keyframes slideInRight {
          from {
            transform: translateX(100%);
            opacity: 0;
          }
          to {
            transform: translateX(0);
            opacity: 1;
          }
        }
        @keyframes slideOutRight {
          from {
            transform: translateX(0);
            opacity: 1;
          }
          to {
            transform: translateX(100%);
            opacity: 0;
          }
        }
      `;
      document.head.appendChild(style);
    }
    
    // 4초 후 제거
    setTimeout(() => {
      if (toast && toast.parentElement) {
        toast.style.animation = 'slideOutRight 0.3s ease-in';
        setTimeout(() => {
          if (toast && toast.parentElement) {
            toast.remove();
          }
        }, 300);
      }
    }, 4000);
    
    console.log('📢 Notification shown:', message);
    
  } catch (error) {
    console.error('❌ Failed to show notification:', error);
  }
}

// 페이지 준비 상태 로깅
console.log('🎯 Simple content script ready');
