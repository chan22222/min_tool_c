// 초간단 테스트 버전 - 확실한 크롭핑
console.log('🔥 ULTRA SIMPLE TEST EXTENSION LOADED');

chrome.commands.onCommand.addListener(async (command) => {
  if (command === 'capture-modal') {
    console.log('🔥🔥🔥 SIMPLE TEST START 🔥🔥🔥');
    
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      // 1. 일단 전체 캡처
      const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, {
        format: 'png',
        quality: 100
      });
      
      console.log('📸 Full screenshot captured, size:', Math.round(dataUrl.length / 1024), 'KB');
      
      // 2. Content script에서 modal 정보 요청 (타임아웃 3초)
      let cropResult = null;
      try {
        console.log('📡 Requesting modal crop from content script...');
        
        cropResult = await Promise.race([
          chrome.tabs.sendMessage(tab.id, {
            action: 'SIMPLE_CROP',
            dataUrl: dataUrl
          }),
          new Promise((_, reject) => 
            setTimeout(() => reject(new Error('3초 타임아웃')), 3000)
          )
        ]);
        
        console.log('✅ Crop result received:', cropResult ? 'SUCCESS' : 'FAILED');
        console.log('📊 Crop details:', cropResult);
        
      } catch (e) {
        console.log('❌ Content script communication failed:', e.message);
      }
      
      // 3. 파일명 및 데이터 결정
      let finalDataUrl = dataUrl;
      let filename = 'FULL_SCREEN_BACKUP.png';
      
      if (cropResult && cropResult.success && cropResult.croppedDataUrl) {
        finalDataUrl = cropResult.croppedDataUrl;
        const safeKeyword = (cropResult.keyword || 'screenshot').replace(/[<>:"/\\|?*]/g, '_');
        filename = `${safeKeyword}_screenshot.png`;
        console.log('✂️ Using CROPPED version, size:', Math.round(finalDataUrl.length / 1024), 'KB');
      } else {
        console.log('📺 Using FULL SCREEN version, size:', Math.round(finalDataUrl.length / 1024), 'KB');
      }
      
      // 4. 다운로드
      const downloadId = await chrome.downloads.download({
        url: finalDataUrl,
        filename: filename,
        saveAs: false,
        conflictAction: 'uniquify'
      });
      
      console.log('💾 Download completed - ID:', downloadId, 'File:', filename);
      
      // 5. 성공 알림
      try {
        chrome.tabs.sendMessage(tab.id, {
          action: 'SHOW_RESULT',
          message: `✅ ${filename} 저장완료!`
        });
      } catch (e) {
        console.log('알림 전송 실패 (정상)');
      }
      
      console.log('🎯 SIMPLE TEST COMPLETED SUCCESSFULLY! 🎯');
      
    } catch (error) {
      console.error('💥 SIMPLE TEST FAILED:', error);
    }
  }
});

console.log('🔥 SIMPLE TEST EXTENSION READY FOR Ctrl+Q');
