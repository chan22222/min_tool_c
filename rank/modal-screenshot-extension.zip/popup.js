document.addEventListener('DOMContentLoaded', async () => {
  
  // 현재 단축키 표시
  try {
    const commands = await chrome.commands.getAll();
    const cmd = commands.find(c => c.name === 'capture-modal');
    
    if (cmd && cmd.shortcut) {
      document.getElementById('currentKey').textContent = cmd.shortcut;
    } else {
      document.getElementById('currentKey').textContent = '미설정';
    }
  } catch (e) {
    console.error(e);
  }
  
  // 캡처 버튼
  document.getElementById('captureBtn').addEventListener('click', () => {
    chrome.runtime.sendMessage({action: 'capture'});
    window.close();
  });
  
  // 설정 버튼
  document.getElementById('settingsBtn').addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });
  
});